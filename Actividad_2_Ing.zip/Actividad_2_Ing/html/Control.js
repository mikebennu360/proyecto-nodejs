$(document).ready(function(){
   $("#divjugadores").show();
   $("#divFormulario").hide();

    cargarJugador();

   
$("#btNuevo").click(function(){
    var x = document.getElementById("divjugadores");
    if (x.style.display === "none") { x.style.display = "block";
    } else {x.style.display = "none";  }

    $("#divFormulario").show();
    $("#txtNombre").empty();
    $("#txtApellido").empty();
    $("#txtAnoNac").empty();
    $("#hdnIdJugador").val(-1);
}); 
   
$("#btnCancelarEditar").click(function(){
    $("#txtNombre").empty();
    $("#txtApellido").empty();
    $("#txtAnoNac").empty();
    $("#hdnIdJugador").val(-1);

    $("#divjugadores").show();
    $("#divFormulario").hide();
});
$("#btnGuardar").click(function(){
    var txtNombre = $("#txtNombre").val();
    var txtApellido = $("#txtApellido").val();
    var txtAnoNac = $("#txtAnoNac").val();
    if (txtNombre == "" || txtApellido == "" || txtAnoNac == "") {
        alert("Debe llenar todos los campos");
    } else {
        guardarJugador();
    }
});

});


function cargarJugador(){
    $("#tbjugadores").empty();
     
    $.get("http://localhost:4000/jugadores",function(data){   
        for(i in data){
            var html= "<tr><td>" + data[i].nombre + "</td><td>" + data[i].apellido + "</td><td class='d-flex justify-content-center'>" + data[i].anoNacimiento + "</td>" +
                      "<td><a href=\"javascript:editarJugador('" + data[i]._id + "','" + data[i].nombre.trim() + "','" + data[i].apellido + "','" + data[i].anoNacimiento + "')\">Modificar</a></td>" +          
                      "<td><a href=\"javascript:eliminarJugador('" + data[i]._id + "')\">Eliminar</a></td></tr>";
                      
            
            $("#tbjugadores").append(html);
         };      
     });
   
}

function guardarJugador(){

    if($("#hdnIdJugador").val()==-1){
        var url="http://localhost:4000/jugadores";
        
        var parametros={
            nombre:$("#txtNombre").val(),
            apellido:$("#txtApellido").val(),
            anoNacimiento:$("#txtAnoNac").val()
        }
    
        $.post(url,parametros,function(data){
            if(data.ok==true){
                cargarJugador();
                $("#divjugadores").show();
                $("#divFormulario").hide();
            }else{
                alert(data.msg);
            }
        });
    }
    else{
        
        var url="http://localhost:4000/jugadores";
        
        var parametros={
            id:$("#hdnIdJugador").val(),
            nombre:$("#txtNombre").val(),
            apellido:$("#txtApellido").val(),
            anoNacimiento:$("#txtAnoNac").val()           
        }
    
        $.ajax(
            {
                url:url,
                type:"put",
                data:parametros,
                success:function(data){                    
                    if(data.ok==true){
                        cargarJugador();
                        $("#divjugadores").show();
                        $("#divFormulario").hide();
                    }else{
                        alert(data.msg);
                    }
                    
                }
            });
    }
    
}

function eliminarJugador(idJugador){
    //create confirm alert 
    var confirmacion = confirm("¿Desea eliminar el jugador?");
    if (confirmacion == true) {
        var url = "http://localhost:4000/jugadores/" + idJugador;
        $.ajax({
            url: url,
            type: "delete",
            success: function (data) {
                if (data.ok == true) {
                    cargarJugador();
                } else {
                    alert(data.msg);
                }
            }
        });
    } else {
        alert("Operación cancelada");
    }
}

function editarJugador(idJugador,nombre,apellido,anoNacimiento){
   
    var x = document.getElementById("divjugadores");
    if (x.style.display === "none") { x.style.display = "block";
    } else {x.style.display = "none";  }

    $("#divFormulario").show();
    $("#txtNombre").empty();
    $("#txtApellido").empty();
    $("#txtAnoNac").empty();
    $("#hdnIdJugador").val(-1);
    
    $("#txtNombre").val(nombre);
    $("#txtApellido").val(apellido);
    $("#txtAnoNac").val(anoNacimiento);
    $("#hdnIdJugador").val(idJugador);
}